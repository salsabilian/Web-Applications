/**
 * CSE183 Assignment 4 - Advanced
 */
class Picker {
  /**
   * Create a date picker
   * @param {string} containerId id of a node the Picker will be a child of
   */  
  constructor(containerId) {
  }
}

