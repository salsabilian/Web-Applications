/**
 * CSE183 Assignment 4 - Stretch
 */
class Spinner {
}

module.exports = Spinner;